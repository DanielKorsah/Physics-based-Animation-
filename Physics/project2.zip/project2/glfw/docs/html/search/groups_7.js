var searchData=
[
  ['standard_20cursor_20shapes',['Standard cursor shapes',['../group__shapes.html',1,'']]]
];
